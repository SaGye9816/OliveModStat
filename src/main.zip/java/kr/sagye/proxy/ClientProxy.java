package kr.sagye.proxy;

import kr.sagye.ui.gui.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class ClientProxy extends CommonProxy {

    public static KeyBinding openShopKey;

    public ClientProxy() {
        FMLCommonHandler.instance().bus().register(this);
    }

    @Override
    public void registerItemRenderer(Item item, int i, String st) {
        ModelLoader.setCustomModelResourceLocation(item, i, new ModelResourceLocation(item.getRegistryName(), st));
    }

    @Override
    public void openGUI(int shopNum) {
        GuiShop gui = null;
        switch (shopNum) {
            case 1:
                gui = new GuiShop1();
                break;
            case 2:
                gui = new GuiShop2();
                break;
            case 3:
                gui = new GuiShop3();
                break;
            case 4:
                gui = new GuiShop4();
                break;
            case 5:
                gui = new GuiShop5();
                break;
            case 6:
                gui = new GuiShop6();
                break;
            case 7:
                gui = new GuiShop7();
                break;
            case 8:
                gui = new GuiShop8();
                break;
            case 9:
                gui = new GuiShop9();
                break;
        }

        GuiShop finalGui = gui;
        Minecraft.getMinecraft().addScheduledTask(() -> Minecraft.getMinecraft().displayGuiScreen(finalGui));
    }


    @Override
    public void init() {
    }


}