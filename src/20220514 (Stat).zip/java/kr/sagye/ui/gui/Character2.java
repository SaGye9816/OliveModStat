package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character2 extends Character {

    public Character2() {
        super(114.4F, 170.73F, 56.4F, 100.73F, new ResourceLocation("omodstat", "textures/gui/kong.png"), new ResourceLocation("omodstat", "textures/gui/kong_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/kong_on.png"), new ResourceLocation("omodstat", "textures/gui/kong_story.png"));
    }

}
