package kr.sagye.creativetab;

import kr.sagye.GGMain;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import kr.sagye.item.MyItem;
import net.minecraft.util.NonNullList;

import java.util.Comparator;

public class CreativeTabWater extends CreativeTabs {

    public static Comparator<ItemStack> tabSorter;
    public CreativeTabWater(String a){
        super(a);
    }

    @Override
    public void displayAllRelevantItems(NonNullList<ItemStack> items) {
        super.displayAllRelevantItems(items);
        items.sort(tabSorter);

    }

    @Override
    public ItemStack createIcon() {
        return new ItemStack(MyItem.GAMGUL);
    }


}
