package kr.sagye;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class GuiPacket implements IMessage {

    int shopNum;

    public GuiPacket() {

    }

    public GuiPacket(int shopNum) {
        this.shopNum = shopNum;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        shopNum = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(shopNum);
    }

    public static class PacketHandler implements IMessageHandler<GuiPacket, IMessage> {

        @Override
        public IMessage onMessage(GuiPacket message, MessageContext ctx) {

            GGMain.proxy.openGUI(message.shopNum);

            return null;
        }

    }
}
