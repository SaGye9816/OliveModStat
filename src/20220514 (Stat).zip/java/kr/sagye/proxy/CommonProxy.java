package kr.sagye.proxy;

public class CommonProxy {

    public void registerKeybind() {
    }

    public void init(){
    }

}
