package kr.sagye.command;

import kr.sagye.GGMain;
import kr.sagye.GuiPacket;
import kr.sagye.NetworkHandler;
import kr.sagye.ui.gui.*;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class UICommand extends CommandBase {

    @Override
    public String getName() {
        return "shop";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "command.shop.usage";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        if (!(sender instanceof EntityPlayerMP)) {
            String msg = "콘솔에서 사용 가능한 명령어가 아닙니다.";
            TextComponentString Text = new TextComponentString(msg);
            Text.getStyle().setColor(TextFormatting.RED);
            sender.sendMessage(Text);

            return;
        }
        if (args != null && args.length >= 0 && args.length != 1) {
            String msg = "사용법 : /shop <상점번호>";
            TextComponentString Text = new TextComponentString(msg);
            Text.getStyle().setColor(TextFormatting.AQUA);
            sender.sendMessage(Text);
        } else if (args != null && args.length == 1) {
            String shopPage = args[0]; // 상점번호
            int shopNum = Integer.parseInt(shopPage);
            if (shopNum < 1 || shopNum > 9) {
                String msg = "올바른 상점번호를 입력해주세요";
                TextComponentString Text = new TextComponentString(msg);
                Text.getStyle().setColor(TextFormatting.AQUA);
                sender.sendMessage(Text);
            } else {

                NetworkHandler.handler.sendTo(new GuiPacket(shopNum), (EntityPlayerMP) sender);
            }

        }
//        GGMain.proxy.commandHandler(server, sender, args);
    }


}
