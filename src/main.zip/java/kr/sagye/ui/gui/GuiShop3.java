package kr.sagye.ui.gui;

import kr.sagye.ui.RenderingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class GuiShop3 extends GuiShop {
    private boolean leftpreDown = false;

    private ResourceLocation bg = new ResourceLocation("ggmod", "textures/gui/3.png");
    private static final ResourceLocation slot = new ResourceLocation("ggmod", "textures/gui/hover.png");

    public void initGui() {
    }


    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);

        boolean leftdown = Mouse.isButtonDown(0);
        boolean leftb = false;

        if (leftdown) {
            if (!this.leftpreDown) {
                leftb = true;
            }
            this.leftpreDown = true;
        } else {
            this.leftpreDown = false;
        }

        int factor = scaledResolution.getScaleFactor();

        float bgx = 0;
        float bgy = 0;

        int mx = mouseX / 2;
        int my = mouseY / 2;

        this.bg = new ResourceLocation("ggmod", "textures/gui/3.png");
        RenderingHelper.drawTexture(bg, bgx, bgy, 1280/factor, 720/factor, 1.0F);

        float btx1 = bgx + 104.8F / 2.0F;
        float bty1 = bgx + 85.76F / 2.0F;

        float btx2 = btx1 + (413 / 4);
        float bty2 = bty1 + (123 / 4);

        if (btx1 <= mx && mx <= btx2) { //왼쪽 버튼
            if (bty1 <= my && my <= bty2) {
                if (leftb) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.ENTITY_EGG_THROW, 1.0F));
                    Minecraft.getMinecraft().player.sendChatMessage("/상점 구매 크로스백");
                }
                if (!leftdown) {
                    RenderingHelper.drawTexture(slot, btx1, bty1, 413 / factor, 123 / factor, 1.0F);
                }
            }
        }

        float btx3 = bgx + 104.8F / 2.0F;
        float bty3 = bgx + 162.76F / 2.0F;

        float btx4 = btx3 + (413 / 4);
        float bty4 = bty3 + (123 / 4);

        if (btx3 <= mx && mx <= btx4) { //왼쪽 버튼
            if (bty3 <= my && my <= bty4) {
                if (leftb) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.ENTITY_EGG_THROW, 1.0F));
                    Minecraft.getMinecraft().player.sendChatMessage("/상점 구매 핸드백");
                }
                if (!leftdown) {
                    RenderingHelper.drawTexture(slot, btx3, bty3, 413 / factor, 123 / factor, 1.0F);
                }
            }
        }
    }
}
