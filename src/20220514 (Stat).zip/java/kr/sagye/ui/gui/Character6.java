package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character6 extends Character {

    public Character6() {
        super(256.4F, 176.73F, 198.4F, 100.73F, new ResourceLocation("omodstat", "textures/gui/ru.png"), new ResourceLocation("omodstat", "textures/gui/ru_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/ru_on.png"), new ResourceLocation("omodstat", "textures/gui/ru_story.png"));
    }

}
