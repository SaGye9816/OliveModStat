package kr.sagye.handler;

import kr.sagye.proxy.ClientProxy;
import kr.sagye.ui.gui.GuiShop;
import kr.sagye.ui.gui.GuiShop1;
import kr.sagye.util.Reference;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber(modid = Reference.MOD_ID, value = Side.CLIENT)
public class ClientHandler {

    static boolean guiPreviousPress = false;

    @SubscribeEvent
    public static void clientTickEvent(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            if (Keyboard.isKeyDown(ClientProxy.openShopKey.getKeyCode())) {
                if (!guiPreviousPress) {
                    if (Minecraft.getMinecraft().currentScreen instanceof GuiShop) {
                        Minecraft.getMinecraft().player.closeScreen();
                    } else {

                        GuiShop1 gui = new GuiShop1();
                        Minecraft.getMinecraft().displayGuiScreen(gui);
                    }
                    guiPreviousPress = true;
                }
            } else {
                guiPreviousPress = false;
            }
        }
        return;
    }
}

