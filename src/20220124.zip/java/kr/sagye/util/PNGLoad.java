package kr.sagye.util;

import net.minecraft.client.renderer.texture.DynamicTexture;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

public class PNGLoad {
    int w, h, id;

    public PNGLoad(String url) {
        try {
            BufferedImage image;

            if (url.contains("http")) {
                image = ImageIO.read(new URL(url));
            } else {
                image = ImageIO.read(new File(url));
            }
            this.w = image.getWidth();
            this.h = image.getHeight();
            this.id = new DynamicTexture(image).getGlTextureId();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public int getID(){
        return this.id;
    }
    public int getHeight(){
        return this.h;
    }
    public int getWidth(){
        return this.w;
    }
}
