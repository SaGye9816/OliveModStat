package kr.sagye.item;

import kr.sagye.item.list.MyYDs;
import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

public class MyItem {
    public static final List<Item> ITEMS = new ArrayList<Item>();

    public static final Item GAMGUL = new MyYDs("gamgul");
    public static final Item LOGO = new MyYDs("logo");
    public static final Item TICKET = new MyYDs("ticket");
    public static final Item YD = new MyYDs("YD");
    public static final Item YPHONE = new MyYDs("yphone");
    public static final Item YDFOOD = new MyYDs("ydfood");
    public static final Item CUSION = new MyYDs("cusion");
    public static final Item LIPSTICK = new MyYDs("lipstick");
    public static final Item LOTION = new MyYDs("lotion");
    public static final Item SHADOW = new MyYDs("shadow");
    public static final Item PORKCUTLET = new MyYDs("porkcutlet");
    public static final Item PASTA = new MyYDs("pasta");
    public static final Item STEAK = new MyYDs("steak");
    public static final Item SUSHI = new MyYDs("sushi");
    public static final Item BIBIMBAP = new MyYDs("bibimbap");
    public static final Item RSOUP = new MyYDs("ricesoup");
    public static final Item CROSSBAG = new MyYDs("crossbag");
    public static final Item HANDBAG = new MyYDs("handbag");
    public static final Item PERFUME = new MyYDs("perfume");
    public static final Item CLUTCH = new MyYDs("clutch");
    public static final Item MANBAG = new MyYDs("manbag");
    public static final Item WATCH = new MyYDs("watch");
    public static final Item BUCKETHAT = new MyYDs("buckethat");
    public static final Item HAIRBAND = new MyYDs("hairband");
    public static final Item COAT = new MyYDs("coat");
    public static final Item DRESS = new MyYDs("dress");
    public static final Item JEAN = new MyYDs("jean");
    public static final Item SCARF = new MyYDs("scarf");
    public static final Item SHIRT = new MyYDs("shirt");
    public static final Item SWEATER = new MyYDs("sweater");
    public static final Item BOOK1 = new MyYDs("book1");
    public static final Item BOOK2 = new MyYDs("book2");
    public static final Item BOOK3 = new MyYDs("book3");
    public static final Item BOOK4 = new MyYDs("book4");
    public static final Item BOOK5 = new MyYDs("book5");
    public static final Item SALMONCUBE = new MyYDs("salmoncube");
    public static final Item ANCHOVY = new MyYDs("anchovy");
    public static final Item DOGFOOD = new MyYDs("dogfood");
    public static final Item JERKY = new MyYDs("jerky");
    public static final Item DRIEDSW = new MyYDs("driedsweetpotato");
    public static final Item CLOTH1 = new MyYDs("cloth1");

}
