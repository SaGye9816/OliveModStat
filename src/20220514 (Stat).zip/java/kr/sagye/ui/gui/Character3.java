package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character3 extends Character {

    public Character3() {
        super(189.4F, 170.73F, 131.4F, 100.73F, new ResourceLocation("omodstat", "textures/gui/daju.png"), new ResourceLocation("omodstat", "textures/gui/daju_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/daju_on.png"), new ResourceLocation("omodstat", "textures/gui/daju_story.png"));
    }

}
