package kr.sagye.item.list;

import net.minecraft.item.Item;
import kr.sagye.GGMain;
import kr.sagye.item.MyItem;
import kr.sagye.util.ItemModel;

public class MyYDs extends Item implements ItemModel {
    public MyYDs(String name){

        setTranslationKey(name);
        setRegistryName(name); //레지스트리상의 이름
        setCreativeTab(GGMain.YDTVTabs); //크리에이티브 탭에 추가해줌

        MyItem.ITEMS.add(this); //MyItem에 있는 변수 리스트에 아이템을 추가해주는 역할
    }

    @Override //기존에 있는 코드들을 덮어쓰는 어노테이션
    public void registerModels() {
        GGMain.proxy.registerItemRenderer(this, 0, "inventory");
    }

}
