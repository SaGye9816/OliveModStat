package kr.sagye;

import com.google.common.collect.Ordering;
import kr.sagye.command.UICommand;
import kr.sagye.item.MyItem;
import kr.sagye.util.Reference;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;
import kr.sagye.creativetab.CreativeTabWater;
import kr.sagye.proxy.CommonProxy;

import java.util.Arrays;
import java.util.List;


@Mod(modid = Reference.MOD_ID, name = Reference.MOD_NAME, version = Reference.VERSION)
public class GGMain {

    public static Logger logger;
    public static final CreativeTabs YDTVTabs = new CreativeTabWater("YDTVTabs");

    public GGMain() {
        NetworkHandler.registerCode();
    }

    @Mod.Instance()
    public static GGMain INSTANCE;

    @SidedProxy(clientSide = Reference.Client_Side, serverSide = Reference.Server_Side)
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preinit(FMLPreInitializationEvent event) {
        List<Item> order = Arrays.asList(MyItem.ITEMS.toArray(new Item[0]));
        CreativeTabWater.tabSorter = Ordering.explicit(order).onResultOf(ItemStack::getItem);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        //두번째 핸들러 (월드젠/IMC메세지/이벤트핸들러/레시피)
        //보통 Mincraft Forge에서 이벤트 버스 레지스터를 활용해서 등록시킴
        proxy.init();
    }

    @Mod.EventHandler
    @SideOnly(Side.CLIENT)
    public void postinit(FMLPostInitializationEvent event) {
        //세번째 핸들러 (모드 호환성개선/ 기타 타 모드 관련)
        Display.setTitle("YDTV X Team. Gamgul");
        //Display.setIcon();
    }

    @Mod.EventHandler
    public void Serverinit(FMLServerStartingEvent event) {
        event.registerServerCommand(new UICommand());
    }
}
