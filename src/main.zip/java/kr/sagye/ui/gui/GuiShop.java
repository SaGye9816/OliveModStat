package kr.sagye.ui.gui;

import net.minecraft.client.gui.GuiScreen;

public abstract class GuiShop extends GuiScreen {

}
