package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character4 extends Character {

    public Character4() {
        super(142.4F, 101.23F, 86.4F, 29.23F, new ResourceLocation("omodstat", "textures/gui/3.png"), new ResourceLocation("omodstat", "textures/gui/3_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/3_on.png"), new ResourceLocation("omodstat", "textures/gui/3_story.png"));
    }

}
