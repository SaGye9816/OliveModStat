package kr.sagye.util;

public interface ItemModel {

    public void registerModels();

}
