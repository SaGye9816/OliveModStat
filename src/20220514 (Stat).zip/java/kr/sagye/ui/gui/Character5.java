package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character5 extends Character {

    public Character5() {
        super(76.4F, 103.23F, 18.4F, 27.23F, new ResourceLocation("omodstat", "textures/gui/nk.png"), new ResourceLocation("omodstat", "textures/gui/nk_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/nk_on.png"), new ResourceLocation("omodstat", "textures/gui/nk_story.png"));
    }

}
