package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character7 extends Character {

    public Character7() {
        super(296.4F, 103.23F, 230.4F, 29.23F, new ResourceLocation("omodstat", "textures/gui/seo.png"), new ResourceLocation("omodstat", "textures/gui/seo_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/seo_on.png"), new ResourceLocation("omodstat", "textures/gui/seo_story.png"));
    }

}
