package kr.sagye.handler;

import kr.sagye.item.MyItem;
import kr.sagye.util.ItemModel;
import kr.sagye.util.Reference;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


@Mod.EventBusSubscriber(modid = Reference.MOD_ID)
public class RegisterHandler {

    @SubscribeEvent
    public static void onItemRegister(RegistryEvent.Register <Item> event){
        event.getRegistry().registerAll(MyItem.ITEMS.toArray(new Item[0]));
        //게임 실행시 마인크래프트가 아이템을 등록시켜주는 과정에서 MyItem.ITEMS에 아이템을 등록시켜줌
    }

    @SubscribeEvent
    public static void onModelRegister(ModelRegistryEvent event){
        //onModelRegister 메소드는 마인크래프트가 아이템들의 모델을 등록해주는 과정에서
        //ITEMS 리스트 내의 아이템들의 모델도 같이 등록하게 만들어줌
        for(Item item:MyItem.ITEMS){
            if(item instanceof ItemModel)  {
                ((ItemModel)item).registerModels();
            }
        }
    }

}
