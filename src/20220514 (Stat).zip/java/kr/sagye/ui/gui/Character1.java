package kr.sagye.ui.gui;

import net.minecraft.util.ResourceLocation;


public class Character1 extends Character {

    public Character1() {
        super(218.4F, 106.73F, 158.4F, 26.73F, new ResourceLocation("omodstat", "textures/gui/yd.png"), new ResourceLocation("omodstat", "textures/gui/yd_stat.png"),
                new ResourceLocation("omodstat", "textures/gui/yd_on.png"), new ResourceLocation("omodstat", "textures/gui/yd_story.png"));
    }

}
