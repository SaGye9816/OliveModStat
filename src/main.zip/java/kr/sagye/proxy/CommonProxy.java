package kr.sagye.proxy;

import kr.sagye.command.UICommand;
import kr.sagye.ui.gui.GuiShop;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommandSender;
import net.minecraft.item.Item;
import net.minecraft.server.MinecraftServer;

public class CommonProxy {
    public void registerItemRenderer(Item item, int i, String st) {
    }

    public void openGUI(int shopNum) {

    }


    public void init(){
    }

}
